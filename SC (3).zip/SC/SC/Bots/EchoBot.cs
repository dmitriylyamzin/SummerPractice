using AdaptiveCards;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
namespace SC.Bots
{
    public class EchoBot : ActivityHandler
    {
        private static int cardNumber = -1;
        private static List<string> symptomsList = new List<string>();
        private static List<double> probabilities = new List<double>();
        private static Controllers.CurrentSymptoms currentSymptoms = new Controllers.CurrentSymptoms(new List<string>());
        private static Controllers.Anemia an = new Controllers.Anemia();
        private static Controllers.AnginaPectoris ap = new Controllers.AnginaPectoris();
        private static Controllers.Arrhythmia ar = new Controllers.Arrhythmia();
        private static Controllers.CoronaryHeartDisease chd = new Controllers.CoronaryHeartDisease();
        private static Controllers.CrerebralCirculationViolation ccv = new Controllers.CrerebralCirculationViolation();
        private static Controllers.HeartCystonia heartCys = new Controllers.HeartCystonia();
        private static Controllers.Hypertension hyper = new Controllers.Hypertension();
        private static Controllers.HypertensionCystonia hyperCys = new Controllers.HypertensionCystonia();
        private static Controllers.HypotensionCystonia hypoCys = new Controllers.HypotensionCystonia();
        private static Controllers.LeftAcuteHeartFailure lahf = new Controllers.LeftAcuteHeartFailure();
        private static Controllers.LeftChronicHeartFailure lchf = new Controllers.LeftChronicHeartFailure();
        private static Controllers.Myocarditis myo = new Controllers.Myocarditis();
        private static Controllers.ParasympatheticCystonia pc = new Controllers.ParasympatheticCystonia();
        private static Controllers.PulmonaryEmbolism pe = new Controllers.PulmonaryEmbolism();
        private static Controllers.RaynaudSyndrome rs = new Controllers.RaynaudSyndrome();
        private static Controllers.RheumaticFever rf = new Controllers.RheumaticFever();
        private static Controllers.RightAcuteHeartFailure rahf = new Controllers.RightAcuteHeartFailure();
        private static Controllers.RightChronicHeartFailure rchf = new Controllers.RightChronicHeartFailure();
        private static Controllers.AnginaPectoris sc = new Controllers.AnginaPectoris();
        private static Controllers.VaricoseVeins vv = new Controllers.VaricoseVeins();
        private static int message_number = 0;
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {


            switch (message_number)
            {
                case 0:
                    await MakeAgeQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 1:
                    await MakeSexQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 2:
                    await MakeWeightQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 3:
                    await MakeHeightQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 4:
                    await MakeCVDQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 5:
                    if (turnContext.Activity.Text == "��")
                    {
                        await MakeCVDList(turnContext, cancellationToken);
                        message_number += 1;
                    }
                    else
                    {
                        await MakeCDQuestion(turnContext, cancellationToken);
                        message_number += 2;
                    }
                    break;
                case 6:
                    await MakeCDQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 7:
                    if (turnContext.Activity.Text == "��")
                    {
                        await MakeCDList(turnContext, cancellationToken);
                        message_number += 1;
                    }
                    else
                    {
                        await MakeIDQuestion(turnContext, cancellationToken);
                        message_number += 2;
                    }
                    break;
                case 8:
                    await MakeIDQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 9:
                    if (turnContext.Activity.Text == "��")
                    {
                        await MakeIDList(turnContext, cancellationToken);
                        message_number += 1;
                    }
                    else
                    {
                        await MakeRDQuestion(turnContext, cancellationToken);
                        message_number += 2;
                    }
                    break;
                case 10:
                    await MakeRDQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 11:
                    await MakeAlcoholQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 12:
                    await MakeSmokeQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 13:
                    await MakeFoodQualityQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 14:
                    await MakeActivityQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;

                case 15:
                    await MakeAllergyQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 16:
                    await MakeInjuryQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 17:
                    await MakeSymptomsList(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 18:
                    await MakeCorrections1(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 19:
                    if (turnContext.Activity.Text == "�������� ��������")
                    {
                        await AddSymptoms(turnContext, cancellationToken);
                        message_number = 18;
                        break;
                    }
                    else
                    {
                        if (turnContext.Activity.Text == "������ ��������")
                        {
                            await DeleteSymptoms(turnContext, cancellationToken);
                            message_number = 20;
                            break;
                        }
                        else
                        {
                            currentSymptoms = new Controllers.CurrentSymptoms(symptomsList);
                            currentSymptoms.RecognizeSymptoms();
                            currentSymptoms.makeSuperstring();
                            System.Console.WriteLine(currentSymptoms.symptomsString);
                            System.Console.WriteLine("!!!!!!!!!!!Going to 22");
                            await turnContext.SendActivityAsync("������ � ����� ��������� ����������� �������� �� ����� ���������. ������?");
                            message_number = 22;
                            break;
                        }
                    }
                case 20:
                    await MakeCorrections2(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 21:
                    if (turnContext.Activity.Text == "�������� ��������")
                    {
                        await AddSymptoms(turnContext, cancellationToken);
                        message_number = 18;
                        break;
                    }
                    else
                    {
                        if (turnContext.Activity.Text == "������ ��������")
                        {
                            await DeleteSymptoms(turnContext, cancellationToken);
                            message_number = 20;
                            break;
                        }
                        else
                        {
                            currentSymptoms = new Controllers.CurrentSymptoms(symptomsList);
                            currentSymptoms.RecognizeSymptoms();
                            currentSymptoms.makeSuperstring();
                            System.Console.WriteLine("!!!!!!!!!!!Going to 22");
                            await turnContext.SendActivityAsync("������ � ����� ��������� ����������� �������� �� ����� ���������. ������?");
                            message_number = 22;
                            break;
                        }
                    }
                case 22:
                    System.Console.WriteLine("!!!!!!!!!!!!!!!case 22");
                    ar.makeSuperstring();
                    an.makeSuperstring();
                    ap.makeSuperstring();
                    chd.makeSuperstring();
                    ccv.makeSuperstring();
                    heartCys.makeSuperstring();
                    hyper.makeSuperstring();
                    hyperCys.makeSuperstring();
                    hypoCys.makeSuperstring();
                    lahf.makeSuperstring();
                    lchf.makeSuperstring();
                    rahf.makeSuperstring();
                    rchf.makeSuperstring();
                    myo.makeSuperstring();
                    pc.makeSuperstring();
                    pe.makeSuperstring();
                    rs.makeSuperstring();
                    rf.makeSuperstring();
                    sc.makeSuperstring();
                    vv.makeSuperstring();
                    System.Console.WriteLine("!!!!!!!!!!!case 22_2");
                    FindProbabilities();
                    System.Console.WriteLine("!!!!!!!!!!!case 22_3");
                    int number = FindNumber();
                    System.Console.WriteLine("!!!!!!!!!!!case 22_4");
                    if (number != -1)
                    {
                        cardNumber = number;
                        await SendCard(cardNumber, turnContext, cancellationToken);
                        message_number = 23;
                    }
                    else
                    {
                        await turnContext.SendActivityAsync("��� ��� ��������� ������. ������ ������ ����������?");
                        message_number = 24;
                    }
                    break;
                case 23:
                    if (turnContext.Activity.Text == "��")
                    {
                        currentSymptoms.symptomsString = currentSymptoms.symptomsString.Substring(0, cardNumber) + "+" + currentSymptoms.symptomsString.Substring(cardNumber + 1);
                    }
                    if (turnContext.Activity.Text == "���")
                    {
                        currentSymptoms.symptomsString = currentSymptoms.symptomsString.Substring(0, cardNumber) + "-" + currentSymptoms.symptomsString.Substring(cardNumber + 1);
                    }
                    if (turnContext.Activity.Text == "�� ����")
                    {
                        currentSymptoms.symptomsString = currentSymptoms.symptomsString.Substring(0, cardNumber) + "�" + currentSymptoms.symptomsString.Substring(cardNumber + 1);
                    }
                    System.Console.WriteLine(currentSymptoms.symptomsString);
                    for (int i = 0; i < 20; i++)
                    {
                        System.Console.WriteLine(probabilities[i]);
                    }
                    await turnContext.SendActivityAsync("�� �������?");
                    message_number = 22;
                    break;
                case 24:
                    for (int i = 0; i < currentSymptoms.symptomsString.Length; i++)
                    {
                        if (currentSymptoms.symptomsString[i] == '?')
                        {
                            if (i == currentSymptoms.symptomsString.Length - 1)
                            {
                                currentSymptoms.symptomsString = currentSymptoms.symptomsString.Substring(0, i) + "-";
                            }
                            else
                            {
                                currentSymptoms.symptomsString = currentSymptoms.symptomsString.Substring(0, i) + "-" + currentSymptoms.symptomsString.Substring(i + 1);
                            }
                        }
                    }
                    FindProbabilities();
                    await PrintResults(turnContext, cancellationToken);
                    break;

            }

        }

        protected async Task PrintResults(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            double max1 = 0;
            double max2 = 0;
            double max3 = 0;
            int i1 = 0;
            int i2 = 0;
            int i3 = 0;
            for (int i = 0; i < probabilities.Count; i++)
            {
                if (probabilities[i] > max1)
                {
                    max3 = max2;
                    max2 = max1;
                    max1 = probabilities[i];
                    i3 = i2;
                    i2 = i1;
                    i1 = i;
                }
                else
                {
                    if (probabilities[i] > max2)
                    {
                        max3 = max2;
                        max2 = probabilities[i];
                        i3 = i2;
                        i2 = i;
                    }
                    else
                    {
                        if (probabilities[i] > max3)
                        {
                            max3 = probabilities[i];
                            i3 = i;
                        }
                    }
                }
            }
            string name1 = FindName(i1);
            string name2 = FindName(i2);
            string name3 = FindName(i3);
            await SendFinalCard(name1, name2, name3, max1, max2, max3, turnContext, cancellationToken);
        }

        protected string FindName(int i)
        {
            if (i == 0)
            {
                return an.title;
            }
            if (i == 1)
            {
                return ar.title;
            }
            if (i == 2)
            {
                return ap.title;
            }
            if (i == 3)
            {
                return chd.title;
            }
            if (i == 4)
            {
                return ccv.title;
            }
            if (i == 5)
            {
                return heartCys.title;
            }
            if (i == 6)
            {
                return hyper.title;
            }
            if (i == 7)
            {
                return hyperCys.title;
            }
            if (i == 8)
            {
                return hypoCys.title;
            }
            if (i == 9)
            {
                return lahf.title;
            }
            if (i == 10)
            {
                return lchf.title;
            }
            if (i == 11)
            {
                return myo.title;
            }
            if (i == 12)
            {
                return pc.title;
            }
            if (i == 13)
            {
                return pe.title;
            }
            if (i == 14)
            {
                return rs.title;
            }
            if (i == 15)
            {
                return rf.title;
            }
            if (i == 16)
            {
                return rahf.title;
            }
            if (i == 17)
            {
                return rchf.title;
            }
            if (i == 18)
            {
                return sc.title;
            }
            if (i == 19)
            {
                return vv.title;
            }
            return "";
        }

        protected int FindNumber()
        {
            int number = -1;
            int illnessId = 0;
            double maxProbability = 0;
            for (int i = 0; i < probabilities.Count; i++)
            {
                if (probabilities[i] > maxProbability)
                {
                    maxProbability = probabilities[i];
                    illnessId = i;
                }
            }
            string priorityString = "";
            if (illnessId == 0)
            {
                priorityString = an.symptomsString;
            }

            if (illnessId == 1)
            {
                priorityString = ar.symptomsString;
            }

            if (illnessId == 2)
            {
                priorityString = ap.symptomsString;
            }

            if (illnessId == 3)
            {
                priorityString = chd.symptomsString;
            }

            if (illnessId == 4)
            {
                priorityString = ccv.symptomsString;
            }

            if (illnessId == 5)
            {
                priorityString = heartCys.symptomsString;
            }

            if (illnessId == 6)
            {
                priorityString = hyper.symptomsString;
            }

            if (illnessId == 7)
            {
                priorityString = hyperCys.symptomsString;
            }

            if (illnessId == 8)
            {
                priorityString = hypoCys.symptomsString;
            }

            if (illnessId == 9)
            {
                priorityString = lahf.symptomsString;
            }

            if (illnessId == 10)
            {
                priorityString = lchf.symptomsString;
            }

            if (illnessId == 11)
            {
                priorityString = myo.symptomsString;
            }

            if (illnessId == 12)
            {
                priorityString = pc.symptomsString;
            }

            if (illnessId == 13)
            {
                priorityString = pe.symptomsString;
            }

            if (illnessId == 14)
            {
                priorityString = rs.symptomsString;
            }

            if (illnessId == 15)
            {
                priorityString = rf.symptomsString;
            }

            if (illnessId == 16)
            {
                priorityString = rahf.symptomsString;
            }

            if (illnessId == 17)
            {
                priorityString = rchf.symptomsString;
            }

            if (illnessId == 18)
            {
                priorityString = sc.symptomsString;
            }

            if (illnessId == 19)
            {
                priorityString = vv.symptomsString;
            }

            for (int i = 0; i < priorityString.Length; i++)
            {
                if ((priorityString[i] == '+' || priorityString[i] == '�' || priorityString[i] == '�') && currentSymptoms.symptomsString[i] == '?')
                {
                    number = i;
                    break;
                }
            }

            return number;
        }

        protected void FindProbabilities()
        {
            if (probabilities.Count == 0)
            {
                for (int i = 0; i < 20; i++)
                {
                    probabilities.Add(0);
                }
            }

            string currentString = currentSymptoms.symptomsString;
            string tempString = an.symptomsString;
            int count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[0] = (double)count / (double)an.countOfPoins;

            tempString = ar.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[1] = (double)count / (double)ar.countOfPoints;

            tempString = ap.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[2] = (double)count / (double)ap.countOfPoints;

            tempString = chd.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[3] = (double)count / (double)chd.countOfPoints;

            tempString = ccv.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[4] = (double)count / (double)ccv.countOfPoints;

            tempString = heartCys.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[5] = (double)count / (double)heartCys.countOfPoints;

            tempString = hyper.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[6] = (double)count / (double)hyper.countOfPoints;

            tempString = hyperCys.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[7] = (double)count / (double)hyperCys.countOfPoints;

            tempString = hypoCys.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[8] = (double)count / (double)hypoCys.countOfPoints;

            tempString = lahf.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[9] = (double)count / (double)lahf.countOfPoints;

            tempString = lchf.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[10] = (double)count / (double)lchf.countOfPoints;

            tempString = myo.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[11] = (double)count / (double)myo.countOfPoints;

            tempString = pc.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[12] = (double)count / (double)pc.countOfPoints;

            tempString = pe.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[13] = (double)count / (double)pe.countOfPoints;

            tempString = rs.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[14] = (double)count / (double)rs.countOfPoints;

            tempString = rf.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[15] = (double)count / (double)rf.countOfPoints;

            tempString = rahf.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[16] = (double)count / (double)rahf.countOfPoints;

            tempString = rchf.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[17] = (double)count / (double)rchf.countOfPoints;

            tempString = sc.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[18] = (double)count / (double)sc.countOfPoints;

            tempString = vv.symptomsString;
            count = 0;
            for (int i = 0; i < currentString.Length; i++)
            {
                if (currentString[i] == '+' && (tempString[i] == '+' || tempString[i] == '�' || tempString[i] == '�'))
                {
                    count += 1;
                }
                if (currentString[i] == '-' && tempString[i] == '-')
                {
                    count += 1;
                }
            }
            probabilities[19] = (double)count / (double)vv.countOfPoints;
        }

        protected async Task MakeCVDQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��������������� �� � ���",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� - ���������� �����������?",

                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
                Data = new AttachmentData().Type = "��"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
                Data = new AttachmentData().Type = "���"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeCDQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� �� � ��� ����������� �����������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��������� ������ ���������� �� ������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
                Data = new AttachmentData().Type = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
                Data = new AttachmentData().Type = "���"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeRDQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� �� � ��� ������������ (��������, �������)",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });

            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ��������-����������� �������������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
                Data = new AttachmentData().Type = "��"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
                Data = new AttachmentData().Type = "���"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task SendFinalCard(string name1, string name2, string name3, double v1, double v2, double v3, ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� ��������� �����������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ������� ����� �����������������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� ��������:",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            if (name1 == "������������� ����������� ��������� ���������������")
            {
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"������������� �����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"��������� ��������������� - {(int)(v1 * 100)}%",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
            }
            else
            {
                if (name1 == "�������������� ����������� ��������� ���������������")
                {
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"������������� �����������",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"��������� ��������������� - {(int)(v1 * 100)}%",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                }
                else
                {
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"{name1} - {(int)(v1 * 100)}%",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                }
            }

            if (name2 == "������������� ����������� ��������� ���������������")
            {
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"������������� �����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"��������� ��������������� - {(int)(v2 * 100)}%",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
            }
            else
            {
                if (name2 == "�������������� ����������� ��������� ���������������")
                {
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"������������� �����������",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"��������� ��������������� - {(int)(v2 * 100)}%",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                }
                else
                {
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"{name2} - {(int)(v2 * 100)}%",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                }
            }

            if (name3 == "������������� ����������� ��������� ���������������")
            {
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"������������� �����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"��������� ��������������� - {(int)(v3 * 100)}%",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
            }
            else
            {
                if (name3 == "�������������� ����������� ��������� ���������������")
                {
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"������������� �����������",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"��������� ��������������� - {(int)(v3 * 100)}%",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                }
                else
                {
                    card.Body.Add(new AdaptiveTextBlock
                    {
                        Text = $"{name3} - {(int)(v3 * 100)}%",
                        Size = AdaptiveTextSize.Medium,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                    });
                }
            }
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = $"��� ������ �� �������� �������.",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = $"��� ���������� ����������� ��������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = $"������������� ���������� � �����.",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task SendCard(int number, ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            if (number == 0)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� �� ������ ���������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����� ��� ������������ ���������� �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������� ���� � ��������� �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 1)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� �� �� ��������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� ����� �� ������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� ������ ������ ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 2)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "� �������� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 3)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���������� ���� ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 4)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ������ ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 5)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ �� � ���",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �������� � �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 6)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� �� �� ������� � �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 7)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���� � �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 8)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� ���������������� ������ �� ���� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 9)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� ����",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� ���� �� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 10)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� �� ��������, ������� � ������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������������� ������� (��������,",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�����������, ������ � �.�.)?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 11)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� ��� � ��������� �����",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = " ��������� ����������� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 12)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� ��� � ��������� �����",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = " ��������� ��������� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 13)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� ��� � ��������� ����� ������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� ����� �� ��������� �������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 14)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���� � ������� ��������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 15)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� � ��� �������������� ��������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 16)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������� �� ���, ��� � ��� ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 17)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ������� � ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 18)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ��������������,",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� ��� ������ ��� ������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �����������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 19)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� �� ������������ �",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� ��������� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 20)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� �� ������� ���������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ � ������ �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 21)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ������������ ����,",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� ��� ������� ���� ���",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� � ������������� ������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 22)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ������ ������ ����������������,",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������, ������ ��� �����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "� ��������� ������ ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 23)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� � ����������������� ����, ���, ���",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ������ ���������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� ������ � ����� ������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 24)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� ����������� ������������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������� ���� ���, ���, ���� ��� ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 25)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����������� ������������ �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����������� ������ �� ����� ������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 26)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ������������ ������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ���������� � ������������ � �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 27)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���� � ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 28)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� ����� ��� ����� ����,",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������� ������� �������� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 29)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���������� ��������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 30)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���������� ������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 31)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ��������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 32)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� � ��������� ��������� ������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� ��� ������ ������/��������� ��������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 33)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "� ��� ���������� �����������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 34)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� �������������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� ����������� ���� � ����������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 35)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� � ���������� �������� � ����� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 36)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� � ���������� �������� � ������ �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 37)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� ���� ����� ����� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 38)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� ����� � ������� ������.",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� �� ����� ������������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 39)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����������� �� � ��� �������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 40)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� �� ��������� ��� �� ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 41)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ����� � ����� ��� �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 42)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ������ ��������������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 43)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����� ��, ��� ������ ��������������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����������� � ������ �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 44)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� �� ������ ������������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� ����� ���� � ��������� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 45)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ��������� ��������� ��������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����, �������� �� ����� � �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 46)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� �� �� ������ ������ ��������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 47)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ �� � ��� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 48)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���� ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 49)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 50)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� ������ ����� ������� �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 51)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ����� ����� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 52)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� ��������� �����",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�� ��� ��� �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 53)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� �������� ��� ������� � �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 54)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� ��� �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 55)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� ����� � ��������� ��������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 56)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 57)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ��������, ��������,",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������� ������������ ��� ������������ ����������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 58)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� ������,",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� �������� ������� ���",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ �������� � ��������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 59)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ����������� � ��������� ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 60)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ��������� ������ � �����",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� ����������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 61)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� �� ��������� ����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� �������� �������� ������ �� ���������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "� �������� � ������� ���������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 62)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� �� �������� ������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "� ��������� ���� ��� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 63)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� ������ ��������� ��������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 64)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���������� ����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� ���������� ���������� �������� �",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 65)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� ��������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ��� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 66)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ��������� ������������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 67)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� �����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� ������������ ������������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 68)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ �� � ��� ������� � ������ ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 69)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����� �� ���� � ������� ������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��� ������� ������ �",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ����� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 70)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ���� �� �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ��� ������� ������ � ����� �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 71)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ���� �� �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ��� ������� ������ � ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 72)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ���� �� �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ��� ������� ������ � ���?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 73)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ���� �� �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ��� ������� ������ � �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 74)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ���� �� �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ ��� ������� ������ � �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 75)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� �������� ����������� � ������� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 76)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �� � ��� �������� ����������� � ������� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 77)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� �� ������ ���������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����� ��� ������������ ���������� �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������� ���� � ��������� �����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 78)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ���� � ������� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 79)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���������� �� �� ���� � ������� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 80)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� �� ���� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 81)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� �� ���� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 82)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� �� ���� ������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 83)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� ������ �������� ����������� �����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ �� ����� ���������� ����������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 84)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�������� ����������� ����������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����� � ���������� ���",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� ����������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 85)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������ �� � ��� ������ ������� ������������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 86)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����� ��, ��� � ��� ����� ���������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "�����, ����� ��� ������ �������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����� �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 87)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ��������������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 88)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� ��� � ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 89)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "� ��� ������ ���������� ��������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 90)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "� ��� ������ ���������� ��������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 91)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "����� ��������� �������� ���� ���������",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });

                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "������������� ��� ������ �����-���� ����������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 92)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "��������� �� ��� �������� ����?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 93)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� �������� ������������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 94)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� ����� � ����� � �������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

            if (number == 95)
            {
                AdaptiveCard card = new AdaptiveCard();
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = "���� ������������?",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "��",
                    Data = new AttachmentData().Type = "��"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "���",
                    Data = new AttachmentData().Type = "���"
                });
                card.Actions.Add(new AdaptiveSubmitAction
                {
                    Title = "�� ����",
                    Data = new AttachmentData().Type = "�� ����"
                });
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
            }

        }

        protected async Task MakeAlcoholQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������������ �� �� ��������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��, ���������",
                Data = new AttachmentData().Type = "��, ���������"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��, �������� �����",
                Data = new AttachmentData().Type = "��, �������� �����"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��, �� �����",
                Data = new AttachmentData().Type = "��, �� �����"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
                Data = new AttachmentData().Type = "���"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeSmokeQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� �� � ��� ���� � ������� ��� ������������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� �������� ���������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
                Data = new AttachmentData().Type = "��"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���, �� ������ ����",
                Data = new AttachmentData().Type = "���, �� ������ ����"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
                Data = new AttachmentData().Type = "���"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeIDQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������ �� �� � ��������� 6 ������� �������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��� ������� ������������� �������������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���������� �������� �����?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
                Data = new AttachmentData().Type = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
                Data = new AttachmentData().Type = "���"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ����",
                Data = new AttachmentData().Type = "�� ����"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeAllergyQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��������� �� ��� ������ �������� ��������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
                Data = new AttachmentData().Type = "��"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
                Data = new AttachmentData().Type = "���"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ����",
                Data = new AttachmentData().Type = "�� ����"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeInjuryQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� �� �� � ������� ��������� ��� �������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = " ������ �����, ����� ��� ������� ������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
                Data = new AttachmentData().Type = "��"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
                Data = new AttachmentData().Type = "���"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ����",
                Data = new AttachmentData().Type = "�� ����"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeFoodQualityQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������� �������� ������ �������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�� ����� �� 0 �� 10",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "7",
                Min = 0,
                Max = 10,
                Value = 0
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeActivityQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������� ������� ����� ����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���������� �� ����� �� 0 �� 10",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "8",
                Min = 0,
                Max = 10,
                Value = 0
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeCVDList(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�����������, ���������� ��� ���������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ��� ��������-���������� �����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "4"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeCDList(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�����������, ����������, ���������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ��� ����������� �����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "5"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeIDList(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�����������, ����������, �������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "����������� ���� ������������ �����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "6"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeAgeQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������� ��� ���?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "1",
                Min = 0,
                Max = 120,
                Value = 40
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeSexQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� ���� ���",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�������",
                Data = new AttachmentData().Type = "�������"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�������",
                Data = new AttachmentData().Type = "�������"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeWeightQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "����� � ��� ���?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "2",
                Min = 20,
                Max = 200,
                Value = 70
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeHeightQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "����� � ��� ����?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "3",
                Min = 110,
                Max = 230,
                Value = 170
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeSymptomsList(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�����������, ����������, ��������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������� ��� ���������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "9",
                Value = "���� � ������, ������, ���� ��� � �.�."
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task AddSymptoms(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            string end = ",";
            System.Console.WriteLine("4!!!!!!!!!!!!!!!!!!!!!!!!!!!! " + symptomsList.Count);
            for (int i = 1; i < symptomsList.Count + 1; i++)
            {
                if (i == symptomsList.Count)
                {
                    end = ".";
                }
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"{symptomsList[i - 1]}{end}",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                }); ;
            }
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������������ ������������ ��� �����",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������ ��������������� � ���������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��� ����� ������ �������������� � �������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "10",
                Value = ""
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task DeleteSymptoms(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            string end = ",";
            System.Console.WriteLine("5!!!!!!!!!!!!!!!!!!!!!!!!!!!! " + symptomsList.Count);
            for (int i = 1; i < symptomsList.Count + 1; i++)
            {
                if (i == symptomsList.Count)
                {
                    end = ".";
                }
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"{symptomsList[i - 1]}{end}",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                }); ;
            }
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������, ����������, ��������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������� ���������� ������� �� ������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "11",
                Value = ""
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeCorrections1(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            SC.Controllers.SymptomsList sl = new SC.Controllers.SymptomsList(turnContext.Activity.Value.ToString().Split(':')[1].Replace('}', ' ').Trim());
            sl.SplitText();
            sl.RecognizeIntents();
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��� ������� ���������� ��������� ��������:",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            string end = ",";
            for (int i = 1; i < symptomsList.Count + 1; i++)
            {
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"{symptomsList[i - 1]}{end}",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                }); ;
            }
            for (int i = 1; i < sl.SymptomList.Count + 1; i++)
            {
                symptomsList.Add(sl.SymptomList[i - 1]);
                if (i == sl.SymptomList.Count)
                {
                    end = ".";
                }
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"{sl.SymptomList[i - 1]}{end}",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                }); ;
            }
            System.Console.WriteLine("1!!!!!!!!!!!!!!!!!!!!!!!!!!!! " + symptomsList.Count);

            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���������, �� �� ���������, � ����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� ��� ������ ��������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� ���-�� �� ���.",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�������� ��������",
                Data = new AttachmentData().Type = "�������� ��������"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "������ ��������",
                Data = new AttachmentData().Type = "������ ��������"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
                Data = new AttachmentData().Type = "�����"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeCorrections2(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            SC.Controllers.SymptomsList sl = new SC.Controllers.SymptomsList(turnContext.Activity.Value.ToString().Split(':')[1].Replace('}', ' ').Trim());
            sl.SplitText();
            sl.RecognizeIntents();
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������ ������ ��������� �������� ���:",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            System.Console.WriteLine("2!!!!!!!!!!!!!!!!!!!!!!!!!!!! " + symptomsList.Count);
            string end = ",";
            for (int i = 1; i < sl.SymptomList.Count + 1; i++)
            {
                symptomsList.Remove(sl.SymptomList[i - 1]);
            }
            System.Console.WriteLine("3!!!!!!!!!!!!!!!!!!!!!!!!!!!! " + symptomsList.Count);
            for (int i = 1; i < symptomsList.Count + 1; i++)
            {
                if (i == symptomsList.Count)
                {
                    end = ".";
                }
                card.Body.Add(new AdaptiveTextBlock
                {
                    Text = $"{symptomsList[i - 1]}{end}",
                    Size = AdaptiveTextSize.Medium,
                    HorizontalAlignment = AdaptiveHorizontalAlignment.Center
                }); ;
            }

            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���������, �� �� ���������, � ����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� ��� ������ ��������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� ���-�� �� ���.",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�������� ��������",
                Data = new AttachmentData().Type = "�������� ��������"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "������ ��������",
                Data = new AttachmentData().Type = "������ ��������"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        /*protected async Task MakeSQ1(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "����������� �� ������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��� ���������� ��������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��� � �������� ���?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeSQ2(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "����� �� � ��� ��������, ��� ��� �� ������� �������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� �� �� ������ ��������� �����",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��� ������������ �����?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
           
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeSQ3(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��� ����� ��� ��������� ������ ������������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });

            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��������� �����/�����",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��������� ����",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ������� ������/�������",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }*/



        protected async Task CreateStartingCard(ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������������!",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ������� ������� ���-���� �� ������ ������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��������������� �� ��������� � ��� ��������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ������� �������� - ���������� �����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��������� ��������"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await CreateStartingCard(turnContext, cancellationToken);
                }
            }
        }
    }
}
