﻿using System.Collections.Generic;

namespace SC.Controllers
{
    public class SymptomsList
    {
        protected List<string> symptomsList = new List<string>();
        protected List<string> intents = new List<string>();
        protected string text;

        public string Text
        {
            set
            {
                text = value;
            }
            get
            {
                return text;
            }
        }

        public List<string> SymptomList
        {
            set
            {
                symptomsList = value;
            }
            get
            {
                return symptomsList;
            }
        }

        public SymptomsList(string _text)
        {
            Text = _text.ToLower().Replace('ё', 'е').Replace("\"", "");
        }

        public void SplitText()
        {
            string[] phrases = text.Split(',');
            foreach (string phrase in phrases)
            {
                intents.Add(phrase);
            }
        }

        public void RecognizeIntents()
        {
            foreach (string intent in intents)
            {
                if (RecognizeSkinProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeThroatProblems(intent));
                }

                if (RecognizeThroatProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeThroatProblems(intent));
                }

                if (RecognizeChestProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeChestProblems(intent));
                }

                if (RecognizeCoughProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeCoughProblems(intent));
                }

                if (RecognizeEyesProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeEyesProblems(intent));
                }

                if (RecognizeHeadProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeHeadProblems(intent));
                }

                if (RecognizeTeethProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeTeethProblems(intent));
                }

                if (RecognizeBowelMovementProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeBowelMovementProblems(intent));
                }

                if (RecognizeNeckProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeNeckProblems(intent));
                }

                if (RecognizeUronationProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeUronationProblems(intent));
                }

                if (RecognizeFaceProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeFaceProblems(intent));
                }

                if (RecognizeLegsProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeLegsProblems(intent));
                }

                if (RecognizeArmsProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeArmsProblems(intent));
                }

                if (RecognizeEyelidProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeEyelidProblems(intent));
                }

                if (RecognizeMouthProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeMouthProblems(intent));
                }

                if (RecognizeMusclesProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeMusclesProblems(intent));
                }

                if (RecognizeHeartProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeHeartProblems(intent));
                }

                if (RecognizeStomachProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeStomachProblems(intent));
                }

                if (RecognizeHypochondriumProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeHypochondriumProblems(intent));
                }

                if (RecognizeLungsProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeLungsProblems(intent));
                }

                if (RecognizeFingerProblems(intent) != "")
                {
                    symptomsList.Add(RecognizeFingerProblems(intent));
                }

                if (RecognizeCollarbone(intent) == 1)
                {
                    symptomsList.Add("боль в ключице");
                }

                if (RecognizeBack(intent) == 1)
                {
                    if (RecognizePain(intent) == 1)
                    {
                        symptomsList.Add("боль в спине");
                    }
                    if (RecognizeSeverity(intent) == 1)
                    {
                        symptomsList.Add("тяжесть в спине");
                    }
                    if (RecognizeEdema(intent) == 1)
                    {
                        symptomsList.Add("отёк спины");
                    }
                    if (RecognizeParalysis(intent) == 1)
                    {
                        symptomsList.Add("скованность спины");
                    }
                }

                if (RecognizeWheezing(intent) == 1)
                {
                    symptomsList.Add("охриплость");
                }

                if (RecognizeHairLoss(intent) == 1)
                {
                    if (RecognizeHead(intent) == 1)
                    {
                        symptomsList.Add("выпадение волос на голове");
                    }
                    else
                    {
                        symptomsList.Add("выпадение волос");
                    }
                }

                if (RecognizeРallucinations(intent) == 1)
                {
                    symptomsList.Add("видения перед глазами");
                }

                if (RecognizeSwallowing(intent) == 1)
                {
                    symptomsList.Add("затруднённое глотание");
                }

                if (RecognizeConstipation(intent) == 1 || (RecognizeBowelMovement(intent) == 1 && RecognizeDifficulty(intent) == 1))
                {
                    symptomsList.Add("запор");
                }

                if (RecognizeGums(intent) == 1 && RecognizeBlood(intent) == 1)
                {
                    symptomsList.Add("кровоточивость дёсен");
                }

                if (RecognizeSputum(intent) == 1 && RecognizeBlood(intent) == 1)
                {
                    symptomsList.Add("кровь в мокроте");
                }

                if (RecognizeHearing(intent) == 1 && (RecognizeImpairment(intent) == 1 || RecognizeDecrease(intent) == 1))
                {
                    symptomsList.Add("нарушение слуха");
                }

                if (RecognizeFainting(intent) == 1 || RecognizeConscience(intent) == 1)
                {
                    symptomsList.Add("обморочное состояние");
                }

                if (RecognizeBreath(intent) == 1)
                {
                    symptomsList.Add("одышка");
                }

                if (RecognizeMood(intent) == 1)
                {
                    if (RecognizeChange(intent) == 1)
                    {
                        symptomsList.Add("нестабильное настроение");
                    }
                    else
                    {
                        if (RecognizeImpairment(intent) == 1)
                        {
                            symptomsList.Add("плохое настроение");
                        }
                    }
                }

                if (RecognizePressure(intent) == 1)
                {
                    if (RecognizeIncrease(intent) == 1)
                    {
                        symptomsList.Add("повышение давления");
                    }
                    else
                    {
                        if (RecognizeDecrease(intent) == 1)
                        {
                            symptomsList.Add("понижение давления");
                        }
                    }
                }

                if (RecognizeSmelling(intent) == 1)
                {
                    if (RecognizeImpairment(intent) == 1 || RecognizeDecrease(intent) == 1)
                    {
                        symptomsList.Add("потеря обоняния");
                    }
                }

                if (RecognizeSweat(intent) == 1)
                {
                    symptomsList.Add("потливость");
                }

                if (RecognizeThirst(intent) == 1)
                {
                    symptomsList.Add("повышенная жажда");
                }

                if (RecognizeVomiting(intent) == 1)
                {
                    symptomsList.Add("рвота");
                }

                if (RecognizeNausea(intent) == 1)
                {
                    symptomsList.Add("тошнота");
                }

                if (RecognizeBruises(intent) == 1)
                {
                    symptomsList.Add("обилие синяков");
                }

                if (RecognizeWeakness(intent) == 1)
                {
                    symptomsList.Add("общая слабость");
                }

                if (RecognizeWeightLoss(intent) == 1 || (RecognizeWeight(intent) == 1 && (RecognizeDecrease(intent) == 1 || RecognizeImpairment(intent) == 1)))
                {
                    if (RecognizeMuscles(intent) == 1)
                    {
                        symptomsList.Add("уменьшение мышечной массы");
                    }
                    else
                    {
                        symptomsList.Add("уменьшение веса");
                    }
                }

                if (RecognizeWeightGain(intent) == 1 || (RecognizeWeight(intent) == 1 && RecognizeIncrease(intent) == 1))
                {
                    symptomsList.Add("увеличение веса");
                }

                if (RecognizeMemory(intent) == 1)
                {
                    if (RecognizeImpairment(intent) == 1 || RecognizeDecrease(intent) == 1)
                    {
                        symptomsList.Add("ухудшение/потеря пямяти");
                    }
                }

                if (RecognizeSight(intent) == 1)
                {
                    if (RecognizeImpairment(intent) == 1 || RecognizeDecrease(intent) == 1)
                    {
                        symptomsList.Add("ухудшение/потеря зрения");
                    }
                }

                if (RecognizeNail(intent) == 1)
                {
                    if (RecognizeFragile(intent) == 1)
                    {
                        symptomsList.Add("хрупкость ногтей");
                    }
                }

                if (RecognizeEars(intent) == 1)
                {
                    if (RecognizeNoise(intent) == 1)
                    {
                        symptomsList.Add("шум в ушах");
                    }
                    if (RecognizeColor(intent) == 7 || RecognizeColor(intent) == 2)
                    {
                        symptomsList.Add("цианоз");
                    }
                }

                if (RecognizeHeat(intent) == 1)
                {
                    symptomsList.Add("чувство жара");
                }

                if (RecognizeCold(intent) == 1)
                {
                    symptomsList.Add("озноб");
                }

                if (RecognizeTemperature(intent) == 1)
                {
                    symptomsList.Add("повышенная температура");
                }

                if (RecognizeSpeech(intent) == 1)
                {
                    if (RecognizeDifficulty(intent) == 1)
                    {
                        symptomsList.Add("затруднённая речь");
                    }
                    else
                    {
                        symptomsList.Add("нарушение речи");
                    }
                }

                if (RecognizeStep(intent) == 1)
                {
                    if (RecognizeDifficulty(intent) == 1)
                    {
                        symptomsList.Add("затруднённая ходьба");
                    }
                    else
                    {
                        if (RecognizePain(intent) == 1)
                        {
                            symptomsList.Add("боль при ходьбе");
                        }
                    }
                }

                if (RecognizeShakiness(intent) == 1)
                {
                    symptomsList.Add("шаткость, неустойчивость");
                }

                if (RecognizeTachycardia(intent) == 1)
                {
                    symptomsList.Add("тахикардия");
                }

                if (RecognizeHiccups(intent) == 1)
                {
                    symptomsList.Add("икота");
                }

                if (RecognizeDiarrhea(intent) == 1)
                {
                    symptomsList.Add("диарея");
                }

                if (RecognizeNose(intent) == 1)
                {
                    if (RecognizeColor(intent) == 7 || RecognizeColor(intent) == 2)
                    {
                        symptomsList.Add("цианоз");
                    }
                    if (RecognizeBlood(intent) == 1)
                    {
                        symptomsList.Add("носовые кровотечения");
                    }
                }

                if (RecognizeFear(intent) == 1)
                {
                    symptomsList.Add("чувство страха");
                }

                if (RecognizeAppetite(intent) == 1)
                {
                    symptomsList.Add("потеря аппетита");
                }

                if (RecognizeOrientation(intent) == 1)
                {
                    symptomsList.Add("проблемы с ориентировкой");
                }

                if (RecognizeEpilepsy(intent) == 1)
                {
                    symptomsList.Add("эпилептический припадок");
                }

                if (RecognizeJoint(intent) == 1 && RecognizePain(intent) == 1)
                {
                    symptomsList.Add("боль в суставах");
                }
            }
        }

        public string RecognizeSkinProblems(string intent)
        {
            if (RecognizeSkin(intent) == 0)
            {
                return "";
            }

            if (RecognizeColor(intent) == 1)
            {
                return "бледность кожи";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "цианоз";
            }

            if (RecognizeColor(intent) == 8)
            {
                return "желтизна кожи";
            }

            if (RecognizeColor(intent) == 3)
            {
                return "потемнение кожи";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение кожи";
            }

            if (RecognizeColor(intent) == 5)
            {
                return "розоватый оттенок кожи";
            }

            if (RecognizeColor(intent) == 6)
            {
                return "почернение кожи";
            }

            if (RecognizeColor(intent) == 7)
            {
                return "цианоз";
            }

            if (RecognizeChange(intent) == 1)
            {
                return "изменение внешнего вида кожи";
            }

            if (RecognizeDryness(intent) == 1)
            {
                return "сухость кожи";
            }

            if (RecognizeImpairment(intent) == 1)
            {
                return "повреждение";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёчность кожи";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в коже";
            }

            if (RecognizeHairLoss(intent) == 1)
            {
                return "выпадение волос на коже";
            }

            if (RecognizeSputum(intent) == 1)
            {
                return "повышенная влажность кожи";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "кожный зуд";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение кожи";
            }

            if (RecognizeFall(intent) == 1)
            {
                return "слезание кожи";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание кожи";
            }

            if (RecognizeUlcers(intent) == 1)
            {
                return "раны (язвы) на коже";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение кожи";
            }

            if (RecognizeIncrease(intent) == 1)
            {
                return "утолщение кожи";
            }

            if (RecognizeWeightGain(intent) == 1)
            {
                return "утолщение кожи";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с кожей";
            }

            return "";
        }

        public string RecognizeThroatProblems(string intent)
        {
            if (RecognizeThroat(intent) == 0)
            {
                return "";
            }

            if (RecognizeColor(intent) == 1)
            {
                return "бледность горла";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "посинение горла";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение горла";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в горле";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд в горле";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение горла";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в горле";
            }

            if (RecognizeUlcers(intent) == 1)
            {
                return "раны (язвы) в горле";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в горле";
            }

            if (RecognizeBlood(intent) == 1)
            {
                return "кровотечение в горле";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк горла";
            }

            if (RecognizeDryness(intent) == 1)
            {
                return "сухость в горле";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность горла";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с горлом";
            }

            return "";
        }

        public string RecognizeChestProblems(string intent)
        {
            if (RecognizeChest(intent) == 0)
            {
                return "";
            }

            if (RecognizeColor(intent) == 1)
            {
                return "бледность грудной клетки";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "посинение грудной клетки";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение грудной клетки";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в грудной клетке";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд в грудной клетке";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение грудной клетки";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в грудной клетке";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в грудной клетке";
            }

            if (RecognizeBlood(intent) == 1)
            {
                return "кровотечение в грудной клетке";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк грудной клетки";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность в грудной клетке";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с грудной клеткой";
            }

            return "";
        }

        public string RecognizeLegsProblems(string intent)
        {
            if (RecognizeLegs(intent) == 0)
            {
                return "";
            }

            if (RecognizeColor(intent) == 1)
            {
                return "бледность ног";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "цианоз";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение ног";
            }

            if (RecognizeColor(intent) == 6)
            {
                return "почернение нижних конечностей";
            }

            if (RecognizeColor(intent) == 7)
            {
                return "цианоз нижних конечностей";
            }

            if (RecognizeColor(intent) == 3)
            {
                return "потемнение нижних конечностей";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в нижних конечностях";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд нижних конечностей";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение нижних конечностей";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в нижних конечностях";
            }

            if (RecognizeUlcers(intent) == 1)
            {
                return "раны (язвы) на ногах";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в ногах";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёки нижних конечностей";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                if (intent.Contains("парал"))
                {
                    return "паралич нижних конечностей";
                }
                return "скованность в ногах";
            }

            if (RecognizeVessel(intent) == 1)
            {
                return "проблемы с сосудами на ногах";
            }

            if (RecognizeVein(intent) == 1)
            {
                return "набухание вен на ногах";
            }

            if (RecognizeSeverity(intent) == 1)
            {
                return "тяжесть в ногах";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "судороги в ногах";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с нижними конечностями";
            }

            return "";
        }

        public string RecognizeFingerProblems(string intent)
        {
            if (RecognizeFinger(intent) == 0)
            {
                return "";
            }

            if (RecognizeColor(intent) == 1)
            {
                return "бледность пальцев";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "посинение пальцев";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение пальцев";
            }

            if (RecognizeColor(intent) == 6)
            {
                return "почернение пальцев";
            }

            if (RecognizeColor(intent) == 7)
            {
                return "цианоз пальцев";
            }

            if (RecognizeColor(intent) == 3)
            {
                return "потемнение пальцев";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в пальцах";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение пальцев";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в пальцах";
            }

            if (RecognizeUlcers(intent) == 1)
            {
                return "раны (язвы) на ногах";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в пальцах";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёки пальцев";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                if (intent.Contains("парал"))
                {
                    return "паралич пальцев";
                }
                return "скованность в пальцах";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "судороги пальцев";
            }

            if (RecognizeUlcers(intent) == 1)
            {
                return "раны (язвы) на пальцах";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с пальцами";
            }

            return "";
        }

        public string RecognizeCoughProblems(string intent)
        {
            if (RecognizeCough(intent) == 0)
            {
                return "";
            }

            if (RecognizeSputum(intent) == 1)
            {
                return "влажный кашель";
            }

            if (RecognizeDryness(intent) == 1)
            {
                return "сухой кашель";
            }

            if (RecognizeBlood(intent) == 1)
            {
                return "кровохарканье";
            }
            return "кашель";
        }

        public string RecognizeEyesProblems(string intent)
        {
            if (RecognizeEye(intent) == 0)
            {
                return "";
            }

            if (RecognizeSputum(intent) == 1)
            {
                return "повышенная влажность глаз";
            }

            if (RecognizeDryness(intent) == 1)
            {
                return "сухость глаз";
            }

            if (RecognizeBlood(intent) == 1)
            {
                return "кровотечение из глаз";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение глаз";
            }

            if (RecognizeColor(intent) == 3)
            {
                return "темнота в глазах";
            }

            if (RecognizePain(intent) == 1)
            {
                return "глазная боль";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "глазной зуд";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение глаз";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание глаз";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в глазах";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк глаз";
            }

            if (RecognizeDoubleVision(intent) == 1)
            {
                return "двоение в глазах";
            }

            if (RecognizeWeakness(intent) == 1)
            {
                return "усталость глаз";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "тремор глаз";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность глаз";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с глазами";
            }

            return "";
        }

        public string RecognizeHeadProblems(string intent)
        {
            if (RecognizeHead(intent) == 0)
            {
                return "";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "посинение головы";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение головы";
            }

            if (RecognizePain(intent) == 1)
            {
                return "головная боль";
            }

            if (RecognizeVertigo(intent) == 1)
            {
                return "головокружение";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд кожи головы";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение головы";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в голове";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк головы";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "тремор головы";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с головой";
            }

            return "";
        }

        public string RecognizeTeethProblems(string intent)
        {
            if (RecognizeTeeth(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "зубная боль";
            }

            if (RecognizeFragile(intent) == 1)
            {
                return "хрупкость зубов";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с зубами";
            }
            return "";
        }

        public string RecognizeBowelMovementProblems(string intent)
        {
            if (RecognizeBowelMovement(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль при дефикации";
            }

            if (RecognizeBlood(intent) == 1)
            {
                return "кровь в стуле";
            }

            if (RecognizeRare(intent) == 1)
            {
                return "нерегулярный стул";
            }

            if (RecognizeSputum(intent) == 1)
            {
                return "жидкий стул";
            }

            return "";
        }

        public string RecognizeNeckProblems(string intent)
        {
            if (RecognizeNeck(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в шее";
            }

            if (RecognizeVein(intent) == 1)
            {
                return "набухание вен на шее";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "посинение шеи";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение шеи";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд шеи";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение шеи";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в шее";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк шеи";
            }

            if (RecognizeUlcers(intent) == 1)
            {
                return "раны (язвы) на шее";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в шее";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "тремор шеи";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность в шее";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с шеей";
            }

            return "";
        }

        public string RecognizeUronationProblems(string intent)
        {
            if (RecognizeUrination(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль при мочеиспускании";
            }

            if (RecognizeBlood(intent) == 1)
            {
                return "кровь в моче";
            }

            if (RecognizeRare(intent) == 1)
            {
                return "нерегулярное мочеиспускание";
            }

            if (RecognizeFrequency(intent) == 1)
            {
                return "частое мочеиспускание";
            }

            if (RecognizeIncontinence(intent) == 1)
            {
                return "недерэжание мочи";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "затруднённое мочеиспускание";
            }

            return "";
        }

        public string RecognizeFaceProblems(string intent)
        {
            if (RecognizeFace(intent) == 0)
            {
                return "";
            }

            if (RecognizeColor(intent) == 1)
            {
                return "бледность лица";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "цианоз";
            }

            if (RecognizeColor(intent) == 3)
            {
                return "потемнение лица";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение лица";
            }

            if (RecognizeColor(intent) == 5)
            {
                return "розоватый оттенок лица";
            }

            if (RecognizeColor(intent) == 6)
            {
                return "почернение лица";
            }

            if (RecognizeColor(intent) == 7)
            {
                return "цианоз";
            }

            if (RecognizeDryness(intent) == 1)
            {
                return "сухость лица";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёчность лица";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в области лица";
            }

            if (RecognizeSputum(intent) == 1)
            {
                return "повышенная влажность кожи на лице";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд кожи лица";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение лица";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание лица";
            }

            if (RecognizeUlcers(intent) == 1)
            {
                return "раны (язвы) на лице";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "лицевой тремор";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с лицом";
            }

            return "";
        }

        public string RecognizeArmsProblems(string intent)
        {
            if (RecognizeArms(intent) == 0)
            {
                return "";
            }

            if (RecognizeColor(intent) == 1)
            {
                return "бледность рук";
            }

            if (RecognizeColor(intent) == 2)
            {
                return "цианоз";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение рук";
            }

            if (RecognizeColor(intent) == 6)
            {
                return "почернение верхних конечностей";
            }

            if (RecognizeColor(intent) == 7)
            {
                return "цианоз верхних конечностей";
            }

            if (RecognizeColor(intent) == 3)
            {
                return "потемнение верхних конечностей";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в верхних конечностях";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд верхних конечностей";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение верхних конечностей";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в верхних конечностях";
            }

            if (RecognizeUlcers(intent) == 1)
            {
                return "раны (язвы) на руках";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение рук";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёки верхних конечностей";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                if (intent.Contains("парал"))
                {
                    return "паралич верхних конечностей";
                }
                return "скованность в руках";
            }

            if (RecognizeVessel(intent) == 1)
            {
                return "проблемы с сосудами на руках";
            }

            if (RecognizeVein(intent) == 1)
            {
                return "набухание вен на руках";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "судороги в руках";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с верхними конечностями";
            }

            return "";
        }

        public string RecognizeEyelidProblems(string intent)
        {
            if (RecognizeEyelid(intent) == 0)
            {
                return "";
            }

            if (RecognizeSputum(intent) == 1)
            {
                return "повышенная влажность век";
            }

            if (RecognizeDryness(intent) == 1)
            {
                return "сухость век";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение века";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в веке";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд века";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение век";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание век";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в веках";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк век";
            }

            if (RecognizeWeakness(intent) == 1)
            {
                return "усталость век";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "тремор век";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность век";
            }

            if (RecognizeFall(intent) == 1)
            {
                return "опущение века";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с веками";
            }

            return "";
        }

        public string RecognizeMouthProblems(string intent)
        {
            if (RecognizeMouth(intent) == 0)
            {
                return "";
            }

            if (RecognizeSputum(intent) == 1)
            {
                return "повышенная влажность во рту";
            }

            if (RecognizeDryness(intent) == 1)
            {
                return "сухость во рту";
            }

            if (RecognizeColor(intent) == 4)
            {
                return "покраснение слизистой оболочки рта";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль во рту";
            }

            if (RecognizeItching(intent) == 1)
            {
                return "зуд ротовой полости";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение ротовой полости";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание во рту";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение во рту";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк рта";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "тремор рта";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность ротовой полости";
            }

            if (RecognizeImpairment(intent) == 1)
            {
                return "повреждение слизистой оболочки рта";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с ротовой полостью";
            }

            return "";
        }

        public string RecognizeMusclesProblems(string intent)
        {
            if (RecognizeMuscles(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в мышцах";
            }

            if (RecognizeNumbness(intent) == 1)
            {
                return "онемение мышц";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в мышцах";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёки мышц";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                if (intent.Contains("парал"))
                {
                    return "паралич мышц";
                }
                return "скованность в мышцах";
            }

            if (RecognizeTremorr(intent) == 1)
            {
                return "судороги в мышцах";
            }

            if (RecognizeWeakness(intent) == 1)
            {
                return "слабость в мышцах";
            }

            if (RecognizeSeverity(intent) == 1)
            {
                return "тяжесть в мышцах";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с мышцами";
            }

            return "";
        }

        public string RecognizeHeartProblems(string intent)
        {
            if (RecognizeHeart(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в области сердца";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в сердце";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк сердца";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность в области сердца";
            }

            if (RecognizeSeverity(intent) == 1)
            {
                return "тяжесть в сердце";
            }

            if (RecognizeInterruptions(intent) == 1)
            {
                return "перебои в работе сердца";
            }

            if (RecognizeFrequency(intent) == 1)
            {
                return "учащённое сердцебиение";
            }

            if (RecognizeRare(intent) == 1)
            {
                return "разреженное сердцебиение";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с сердцем";
            }

            return "";
        }

        public string RecognizeStomachProblems(string intent)
        {
            if (RecognizeStomach(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в животе";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в животе";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк живота";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность в области живота";
            }

            if (RecognizeSeverity(intent) == 1)
            {
                return "тяжесть в животе";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в животе";
            }

            if (RecognizeBlood(intent) == 1)
            {
                return "кровотечение в животе";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с животом";
            }

            return "";
        }

        public string RecognizeLiverProblems(string intent)
        {
            if (RecognizeLiver(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в печени";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в печени";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк печени";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность в области печени";
            }

            if (RecognizeSeverity(intent) == 1)
            {
                return "тяжесть в печени";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в печени";
            }

            if (RecognizeBlood(intent) == 1)
            {
                return "кровотечение в печени";
            }

            if (RecognizeIncrease(intent) == 1)
            {
                return "увеличение печени";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с печенью";
            }

            return "";
        }

        public string RecognizeHypochondriumProblems(string intent)
        {
            if (RecognizeHypochondrium(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в подреберье";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в подреберье";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк подреберья";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность под ребром";
            }

            if (RecognizeSeverity(intent) == 1)
            {
                return "тяжесть в ребрах";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в подреберье";
            }

            return "";
        }

        public string RecognizeLungsProblems(string intent)
        {
            if (RecognizeLungs(intent) == 0)
            {
                return "";
            }

            if (RecognizePain(intent) == 1)
            {
                return "боль в легких";
            }

            if (RecognizeTingle(intent) == 1)
            {
                return "покалывание в легких";
            }

            if (RecognizeEdema(intent) == 1)
            {
                return "отёк легких";
            }

            if (RecognizeParalysis(intent) == 1)
            {
                return "скованность в легких";
            }

            if (RecognizeSeverity(intent) == 1)
            {
                return "тяжесть в легких";
            }

            if (RecognizeBurning(intent) == 1)
            {
                return "жжение в легких";
            }

            if (RecognizeSputum(intent) == 1)
            {
                return "наличие жидкости в легких";
            }

            if (RecognizeDifficulty(intent) == 1)
            {
                return "проблемы с дыханием";
            }

            if (RecognizeCold(intent) == 1)
            {
                return "чувство холода";
            }

            return "";
        }

        public int RecognizeColor(string intent)
        {
            List<string> colorExpressions = new List<string> { "белый", "белого", "белая", "белым", "белые", "беловат", "белес", "белесоват", "бледн", "бледноват", "синий", "синего", "синяя", "синим", "синие", "синеват", "синюшн", "синен", "синею", "синее", "темне", "темный", "темного", "темным", "темная", "темные", "красн", "гиперми", "розов", "черн", "цианоз", "желт" };
            int expressionNumber = 0;
            foreach (string expression in colorExpressions)
            {
                if (intent.Contains(expression))
                {
                    if (expressionNumber < 10)
                    {
                        return 1;
                    }
                    if (expressionNumber < 20)
                    {
                        return 2;
                    }
                    if (expressionNumber < 26)
                    {
                        return 3;
                    }
                    if (expressionNumber < 28)
                    {
                        return 4;
                    }
                    if (expressionNumber < 29)
                    {
                        return 5;
                    }
                    if (expressionNumber < 30)
                    {
                        return 6;
                    }
                    if (expressionNumber < 31)
                    {
                        return 7;
                    }
                    if (expressionNumber < 32)
                    {
                        return 8;
                    }
                }
                expressionNumber += 1;
            }
            return 0;

        }

        public int RecognizePain(string intent)
        {
            List<string> painExpressions = new List<string> { " боль ", "боли", "болит", "болезнен", "больн", "дискомф", "некомф" };
            if (intent.StartsWith("боль") || intent.EndsWith("боль"))
            {
                return 1;
            }
            foreach (string expression in painExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSkin(string intent)
        {
            List<string> skinExpressions = new List<string> { "кожи", "кожный", "кожного", "коже", "кожа", "кожей", "кожным", "кожные", "кожных" };
            foreach (string expression in skinExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeThroat(string intent)
        {
            List<string> throatExpressions = new List<string> { "глотк", "горло", "горла", "горле", "горлу", "гортан", "горлов", "горлом" };
            foreach (string expression in throatExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeChest(string intent)
        {
            List<string> chestExpressions = new List<string> { "груди", "грудная", "грудной", "грудном", "грудные", "грудных", "грудь", "клетк" };
            foreach (string expression in chestExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeLegs(string intent)
        {
            List<string> legsExpressions = new List<string> { "нога", "ноги", "ногой", "ноге", "ногу", "ноги", " ног ", "ногами", "ногам", "ногах", "ступни", "ступня", "ступнях", "ступнями", "ступней", "ступню", "ступне", "нижние конечности", "нижние части тела", "нижняя конечность", "нижняя часть тела", "нижних конечностей", "нижних частей тела", "нижней конечности", "нижней части тела", "нижней конечности", "нижним частям тела", "нижнюю конечность", "нижнюю часть тела", "нижними конечностями", "нижними частями тела", "нижней конечностью", "нижней частью тела", "нижних конечностях", "нижних частях тела", "бедр", "голен", " икр ", "икроно", "икры", "колен" };
            if (intent.EndsWith(" ног") || intent.EndsWith(" икр"))
            {
                return 1;
            }
            foreach (string expression in legsExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeHairLoss(string intent)
        {
            List<string> hairLossExpressions = new List<string> { "выпадение волос", "выпадают волосы", "теряю волосы", "потеря волос", "редеют волосы", "лысин", "облысен", "лысею", "пореде", "истонченые волос", "утонечение волос", "истончаются волосы", "утончаются волосы" };
            foreach (string expression in hairLossExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeCough(string intent)
        {
            List<string> coughExpressions = new List<string> { "кашляю", "кашель", "кашля", "покашл", "кашле" };
            foreach (string expression in coughExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeDryness(string intent)
        {
            List<string> drynessExpressions = new List<string> { "сухой", "сухим", "сухом", "сухого", "без мокрот", "нет мокрот", "мокроты нет", "мокрота отсутствует", "отсутствии мокроты", "с отсутствием мокроты", "сухост", "пересых", "осуш", "высуш", "высых", "иссых", "иссуш" };
            foreach (string expression in drynessExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSputum(string intent)
        {
            List<string> sputumExpressions = new List<string> { "мокрый", "жидки", "влажн", "мокрого", "мокрым", "мокром", "мокрот" };
            foreach (string expression in sputumExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeРallucinations(string intent)
        {
            List<string> hallucinationsExpressions = new List<string> { "глюк", "галлюц", "галюц", "видени", "мираж", "мушки", "мушек", "белые штуки", "белые штучки", "белых штучек", "мушками", "рябь", "рябит", "рябени" };
            foreach (string expression in hallucinationsExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeEye(string intent)
        {
            List<string> eyeExpressions = new List<string> { "роговиц", "сетчатк", "хрусталик", "зрачк", "глаз", "склер", "радужк", "слепот", "ослеп", "пятн", "пятен", "слепы" };
            foreach (string expression in eyeExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeHead(string intent)
        {
            List<string> headExpressions = new List<string> { "мозг", "голов" };
            foreach (string expression in headExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeVertigo(string intent)
        {
            List<string> vertigoExpressions = new List<string> { "круж", "кругом" };
            foreach (string expression in vertigoExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeDoubleVision(string intent)
        {
            List<string> doubleVisionExpressions = new List<string> { "двоит", "троит", "раздва", "растраивается", "раздвое", "растрое", "расплыв", "плыве", "плыву", "плава" };
            foreach (string expression in doubleVisionExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeConstipation(string intent)
        {
            List<string> constipationExpressions = new List<string> { "запор" };
            foreach (string expression in constipationExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSwallowing(string intent)
        {
            List<string> swallowingExpressions = new List<string> { "глота", "проглот", "проглат", "дисфаг" };
            foreach (string expression in swallowingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeDifficulty(string intent)
        {
            List<string> difficultyExpressions = new List<string> { "с трудом", "трудн", "проблем", "сложн", "тяжело", "непрост", "неприят", "не могу", "нельзя", "невозмож", "не возмож" };
            foreach (string expression in difficultyExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeTeeth(string intent)
        {
            List<string> teethExpressions = new List<string> { "зубы", "зубов", "зубами", "зубн", "зубах", " зуб ", "зуба", "зубам", "зубе", "зубу", "челюст" };
            if (intent.StartsWith("зуб ") || intent.EndsWith(" зуб"))
            {
                return 1;
            }
            foreach (string expression in teethExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeItching(string intent)
        {
            List<string> itchingExpressions = new List<string> { " зуд ", "зудит", "чешется", "чесотка" };
            if (intent.StartsWith("зуд ") || intent.EndsWith(" зуд"))
            {
                return 1;
            }
            foreach (string expression in itchingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeChange(string intent)
        {
            List<string> changeExpressions = new List<string> { "поменя", "смен", "измен", "перемен", "перепад" };
            foreach (string expression in changeExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeBlood(string intent)
        {
            List<string> bloodExpressions = new List<string> { "кровь", "кровян", "кровоточ", "крови", "кровью", "кровообр", "кровенос", "кровохаркан", "кровотеч" };
            foreach (string expression in bloodExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeBowelMovement(string intent)
        {
            List<string> bowelMovementExpressions = new List<string> { "опорож", "кал", "дефикац", "стул" };
            foreach (string expression in bowelMovementExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeGums(string intent)
        {
            List<string> gumsExpressions = new List<string> { "десн", "десен" };
            foreach (string expression in gumsExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeIncrease(string intent)
        {
            List<string> increaseExpressions = new List<string> { "набор", "набира", "расте", "расти", "рост ", " рост", " рост ", "увелич", "повыш", "набух", "расшир", "подня", "вырос", "повыс", "усилив", "усилил", "усилен", "утолщ" };
            foreach (string expression in increaseExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeDecrease(string intent)
        {
            List<string> decreaseExpressions = new List<string> { "паден", "сниж", "снизи", "упал", "падае", "уменьш", "меньше", "пониж", "пониз", "нехватк", "сокращ" };
            foreach (string expression in decreaseExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeVein(string intent)
        {
            List<string> veinExpressions = new List<string> { " вен", "вен ", "вена", "вены", "вене", "вену", "венам", "венами", "венах", "веноз" };
            foreach (string expression in veinExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeNeck(string intent)
        {
            List<string> neckExpressions = new List<string> { " шея", " шею", " шее", " шеи", " шеей" };
            if (intent.StartsWith("шея"))
            {
                return 1;
            }
            foreach (string expression in neckExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeHearing(string intent)
        {
            List<string> hearingExpressions = new List<string> { "слух", "слыш" };
            foreach (string expression in hearingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeIncontinence(string intent)
        {
            List<string> incontinenceExpressions = new List<string> { "недерж" };
            foreach (string expression in incontinenceExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeUrination(string intent)
        {
            List<string> urinationExpressions = new List<string> { "мочеисп", "моча", " моче", " мочи", "мочой" };
            foreach (string expression in urinationExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeFainting(string intent)
        {
            List<string> faintingExpressions = new List<string> { "обморок", "обмороч" };
            foreach (string expression in faintingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeBreath(string intent)
        {
            List<string> breathExpressions = new List<string> { "одышк", "дыха", "вдох", "выдох", "дыша", "вздох", "вздых", "выдых", "задых", "удушь", "кислор", "воздух", "удушл" };
            foreach (string expression in breathExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeWheezing(string intent)
        {
            List<string> wheezingExpressions = new List<string> { "хрип" };
            foreach (string expression in wheezingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeImpairment(string intent)
        {
            List<string> impairmentExpressions = new List<string> { "ухудш", "плох", "хуж", "наруш", "потер", "пропа", "исчез", "отсутст", "не чуст", "нет", "без", "поврежд", "повред" };
            foreach (string expression in impairmentExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeRare(string intent)
        {
            List<string> rareExpressions = new List<string> { "редк", "медл", "реже", "нечаст", "нерегул", "непостоя", "задерж" };
            foreach (string expression in rareExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeFrequency(string intent)
        {
            List<string> freqExpressions = new List<string> { "чащ", "часты", "часта", "часто", "ускор", "убыстр", "регул", "постоян", "сильн", "резк", "учащ", "остр" };
            if (intent.Contains("нерегул") || intent.Contains("непостоян"))
            {
                return 0;
            }
            foreach (string expression in freqExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeNumbness(string intent)
        {
            List<string> numbnessExpressions = new List<string> { "онеме", "немее", "немею", "не чувств", "потеря чувств", "отсутствие чувств" };
            foreach (string expression in numbnessExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeArms(string intent)
        {

            List<string> armsExpressions = new List<string> { "рука", "руки", "рукой", "руке", "руку", "руки", " рук", "руками", "рукам", "руках", "ладони", "ладонь", "ладоней", "ладонями", "ладоням", "ладонью", "верхние конечности", "верхние части тела", "верхняя конечность", "верхняя часть тела", "верхних конечностей", "верхних частей тела", "верхней конечности", "верхней части тела", "верхней конечности", "верхним частям тела", "верхнюю конечность", "верхнюю часть тела", "верхними конечностями", "верхними частями тела", "верхней конечностью", "верхней частью тела", "верхних конечностях", "верхних частях тела", "плеч", "кист", "локт", "локот", "предплеч" };
            foreach (string expression in armsExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeEyelid(string intent)
        {

            List<string> eyelidExpressions = new List<string> { "века", "веко", "веки", " век" };
            foreach (string expression in eyelidExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeFall(string intent)
        {

            List<string> fallExpressions = new List<string> { "опуск", "опусти", "опущ", "съех", "упало", "спало", "упали", "спали", "упала", "спала", "птоз", "слезан", "слезл" };
            foreach (string expression in fallExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeFace(string intent)
        {

            List<string> faceExpressions = new List<string> { "щек", "лиц", "лбу", "лба", "лоб" };
            foreach (string expression in faceExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeEdema(string intent)
        {

            List<string> edemaExpressions = new List<string> { "эдем", "эдэм", "отек", "отечн", "пухл", "пухае" };
            foreach (string expression in edemaExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeMood(string intent)
        {

            List<string> moodExpressions = new List<string> { "настрое", "апатия", "раздраж", "рассея", "расея", "апатии", "апатие", "апатич" };
            foreach (string expression in moodExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizePressure(string intent)
        {

            List<string> pressureExpressions = new List<string> { "давлен", "артериал", " ад ", "давит", "давят", "сдавл", "стесн" };
            if (intent.StartsWith("ад ") || intent.EndsWith(" ад"))
            {
                return 1;
            }
            foreach (string expression in pressureExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSmelling(string intent)
        {

            List<string> smellingExpressions = new List<string> { "обонян", "запах", "пахн", "обоян" };
            foreach (string expression in smellingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeFeeling(string intent)
        {

            List<string> feelingExpressions = new List<string> { "чувств", "ощущ" };

            foreach (string expression in feelingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSweat(string intent)
        {

            List<string> sweatExpressions = new List<string> { "потлив", "потеть", "потею", "пота", " пот", "потоод", "потно" };

            foreach (string expression in sweatExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeThirst(string intent)
        {

            List<string> thirstExpressions = new List<string> { "жажд", "пить", "пью" };

            foreach (string expression in thirstExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeNausea(string intent)
        {

            List<string> nauseaExpressions = new List<string> { "тошн" };

            foreach (string expression in nauseaExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeVomiting(string intent)
        {

            List<string> vomitingExpressions = new List<string> { "рвет", "вырвало", "вырывает", "рвот" };

            foreach (string expression in vomitingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeBruises(string intent)
        {

            List<string> bruisesExpressions = new List<string> { "синяк" };

            foreach (string expression in bruisesExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeWeakness(string intent)
        {
            List<string> weaknessExpressions = new List<string> { "слабос", "утомляем", "утомлен", "утомит", "устало", "устаю", "сонлив", "вяло", "недомог", "изнемож" };

            foreach (string expression in weaknessExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeMuscles(string intent)
        {

            List<string> musclesExpressions = new List<string> { "мышц", "мышеч", "мускул", "мышыц", "мышец" };

            foreach (string expression in musclesExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeWeight(string intent)
        {

            List<string> weightExpressions = new List<string> { " вес", "массы", "масса", "массе", "массой", };

            foreach (string expression in weightExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeHeart(string intent)
        {

            List<string> heartExpressions = new List<string> { "сердц", "сердеч" };

            foreach (string expression in heartExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeJoint(string intent)
        {

            List<string> jointExpressions = new List<string> { "сустав" };

            foreach (string expression in jointExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeVessel(string intent)
        {

            List<string> vesselExpressions = new List<string> { "сосуд", "капиляр", "капилляр", "каппиляр" };

            foreach (string expression in vesselExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeTremorr(string intent)
        {

            List<string> tremorrExpressions = new List<string> { "тремор", "судорог", "судорож", "дерга", "подерги" };

            foreach (string expression in tremorrExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeMemory(string intent)
        {

            List<string> memoryExpressions = new List<string> { "памят", "амнези" };

            foreach (string expression in memoryExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSight(string intent)
        {

            List<string> sightExpressions = new List<string> { "виж", "зрени" };
            if (intent.Contains("подозрени"))
            {
                return 0;
            }
            foreach (string expression in sightExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeFragile(string intent)
        {

            List<string> fragileExpressions = new List<string> { "хрупк", "ломк", "ломают", "поломк", "сломан" };
            foreach (string expression in fragileExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeNail(string intent)
        {

            List<string> nailExpressions = new List<string> { "ногт", "ногот" };
            foreach (string expression in nailExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeHeat(string intent)
        {

            List<string> nailExpressions = new List<string> { " жар" };
            foreach (string expression in nailExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeTemperature(string intent)
        {

            List<string> temperatureExpressions = new List<string> { "температур", "лихорад" };
            foreach (string expression in temperatureExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeBig(string intent)
        {

            List<string> bigExpressions = new List<string> { "огром", "сильн", "высок" };
            foreach (string expression in bigExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeEars(string intent)
        {

            List<string> earsExpressions = new List<string> { " ухо", "ухо ", " уха", "уха ", " ухе", "ухе ", "уши ", " уши", "ушах ", " ушах", "ушей ", " ушей" };
            foreach (string expression in earsExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeNoise(string intent)
        {

            List<string> noiseExpressions = new List<string> { "звук", "шум ", " шум", "залож", "звени", "звон ", " звон" };
            foreach (string expression in noiseExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeNose(string intent)
        {

            List<string> noseExpressions = new List<string> { "нос ", " нос" };
            foreach (string expression in noseExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeFinger(string intent)
        {

            List<string> fingerExpressions = new List<string> { "пальц", "палец" };
            foreach (string expression in fingerExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeFear(string intent)
        {

            List<string> fearExpressions = new List<string> { "страх", "страш", "беспок", "боязн", "боюсь" };
            foreach (string expression in fearExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeAppetite(string intent)
        {

            List<string> appetiteExpressions = new List<string> { "апетит", "аппетит", "есть" };
            foreach (string expression in appetiteExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeMouth(string intent)
        {

            List<string> mouthExpressions = new List<string> { "во рту", " рта", "в роте" };
            foreach (string expression in mouthExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeConscience(string intent)
        {

            List<string> conscienceExpressions = new List<string> { "сознан" };
            foreach (string expression in conscienceExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeInterruptions(string intent)
        {

            List<string> interruptionsExpressions = new List<string> { "перебо", "сбивч", "сбива", "сбои" };
            foreach (string expression in interruptionsExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeTingle(string intent)
        {

            List<string> tingleExpressions = new List<string> { "покалыв", "колетс", "колюч", "колитс", "колящ" };
            foreach (string expression in tingleExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeCold(string intent)
        {

            List<string> coldExpressions = new List<string> { "холод", "озноб", "зноби", "зноблен" };
            foreach (string expression in coldExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeStep(string intent)
        {

            List<string> stepExpressions = new List<string> { "идти", "ходить", "ходьб", "хотьб", "походк" };
            foreach (string expression in stepExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeLittle(string intent)
        {

            List<string> littleExpressions = new List<string> { "маленьк", "небольш", "незнач", "невысок" };
            foreach (string expression in littleExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeParalysis(string intent)
        {

            List<string> paralysisExpressions = new List<string> { "паралич", "парализ", "сковал", "скован" };
            foreach (string expression in paralysisExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSpeech(string intent)
        {

            List<string> speechExpressions = new List<string> { "речи", "речь", "речью", "речей", "голос" };
            foreach (string expression in speechExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeShakiness(string intent)
        {

            List<string> shakinessExpressions = new List<string> { "шатк", "валитс", "стоять", "валитьс", "неустойч" };
            foreach (string expression in shakinessExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeUlcers(string intent)
        {

            List<string> ulcersExpressions = new List<string> { "язв", " рана", "раны ", " раны", "рана ", " ран ", "ранок", "ранки" };
            if (intent.EndsWith(" ран"))
            {
                return 1;
            }
            foreach (string expression in ulcersExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSudden(string intent)
        {

            List<string> suddenExpressions = new List<string> { "внезап", "неожид", "стремит" };
            foreach (string expression in suddenExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }
        public int RecognizeExercuses(string intent)
        {

            List<string> exercuseExpressions = new List<string> { "физич", "активн", "нагруз" };
            foreach (string expression in exercuseExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSide(string intent)
        {

            List<string> sideExpressions = new List<string> { "левой", "левая", "слева", "влево", "правая", "правой", "справа", "вправо", "справо", "слево", "направа", "налево", "левую", "правую", "центр", "середи", "средн" };
            foreach (string expression in sideExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeSeverity(string intent)
        {

            List<string> severityExpressions = new List<string> { "тяжест" };
            foreach (string expression in severityExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeTachycardia(string intent)
        {

            List<string> tachycardiaExpressions = new List<string> { "пульс", "тахикард", "сердечных сокращений", "сердечные сокращения" };
            if (intent.Contains("пульсир"))
            {
                return 0;
            }
            foreach (string expression in tachycardiaExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeBurning(string intent)
        {

            List<string> burningExpressions = new List<string> { "жжет", "жжен" };
            foreach (string expression in burningExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeStomach(string intent)
        {

            List<string> stomachExpressions = new List<string> { "живот", "желуд", "селезен", "кишечн" };
            foreach (string expression in stomachExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeHypochondrium(string intent)
        {

            List<string> hypochondriumExpressions = new List<string> { "под ребром", "под ребрами", "за ребром", "за ребрами", "в ребрах", "в ребре", "подребер" };
            foreach (string expression in hypochondriumExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeLungs(string intent)
        {

            List<string> lungsExpressions = new List<string> { "легки", "легоч" };
            foreach (string expression in lungsExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeGiving(string intent)
        {

            List<string> givingExpressions = new List<string> { "отдающ", "отдает", "отдавающ", "распростр" };
            foreach (string expression in givingExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeBlade(string intent)
        {

            List<string> bladeExpressions = new List<string> { "лопатк", "лопаточ" };
            foreach (string expression in bladeExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeCollarbone(string intent)
        {

            List<string> collarboneExpressions = new List<string> { "ключич", "ключиц" };
            foreach (string expression in collarboneExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeBack(string intent)
        {

            List<string> backExpressions = new List<string> { "спина", "спины", "спинн", "спину", "спиной", "спине" };
            foreach (string expression in backExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeHiccups(string intent)
        {

            List<string> hiccupsExpressions = new List<string> { "икот", "икание", "икать", "икаю" };
            foreach (string expression in hiccupsExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeDiarrhea(string intent)
        {

            List<string> diarrheaExpressions = new List<string> { "диарре", "диаре" };
            foreach (string expression in diarrheaExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeWeightLoss(string intent)
        {

            List<string> weightLossExpressions = new List<string> { "похуд" };
            foreach (string expression in weightLossExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeWeightGain(string intent)
        {

            List<string> weightGainExpressions = new List<string> { "потолст", "растолст", "ожир" };
            foreach (string expression in weightGainExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeUp(string intent)
        {

            List<string> upExpressions = new List<string> { "вверх", "сверх", "верхн", "наверх", "на верх", "в верх", "с верх" };
            foreach (string expression in upExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeDown(string intent)
        {

            List<string> upExpressions = new List<string> { "нижн", "сниз", "вниз", "в низ", "с низ" };
            foreach (string expression in upExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeLiver(string intent)
        {

            List<string> liverExpressions = new List<string> { "печен" };
            foreach (string expression in liverExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeEpilepsy(string intent)
        {

            List<string> epilepsyExpressions = new List<string> { "эпилеп" };
            foreach (string expression in epilepsyExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizeOrientation(string intent)
        {

            List<string> epilepsyExpressions = new List<string> { "ориентац", "ориентир" };
            foreach (string expression in epilepsyExpressions)
            {
                if (intent.Contains(expression))
                {
                    return 1;
                }
            }
            return 0;
        }

        public int RecognizePainTypes(string intent)
        {

            List<string> painTypesExpressions = new List<string> { "ноющ", "колющ", "прострелив", "режущ", "пульсир", "давящ", "сжима", "тянущ", "притупленн", "стреля" };
            int expressionNumber = 0;
            foreach (string expression in painTypesExpressions)
            {
                if (intent.Contains(expression))
                {
                    if (expressionNumber == 0)
                    {
                        return 1;
                    }
                    if (expressionNumber == 1)
                    {
                        return 2;
                    }
                    if (expressionNumber == 2)
                    {
                        return 3;
                    }
                    if (expressionNumber == 3)
                    {
                        return 4;
                    }
                    if (expressionNumber == 4)
                    {
                        return 5;
                    }
                    if (expressionNumber == 5)
                    {
                        return 6;
                    }
                    if (expressionNumber == 6)
                    {
                        return 7;
                    }
                    if (expressionNumber == 7)
                    {
                        return 8;
                    }
                    if (expressionNumber == 8)
                    {
                        return 9;
                    }
                    if (expressionNumber == 9)
                    {
                        return 10;
                    }

                }
                expressionNumber += 1;
            }
            return 0;
        }
    }
}
