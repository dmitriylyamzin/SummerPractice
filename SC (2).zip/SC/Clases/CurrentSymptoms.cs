﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clases
{
    public class CurrentSymptoms
    {
        public List<string> symptomsList;
        public string headache = "????";
        public string highPressure = "??";
        public string lowPressure = "?";
        public string earNoise = "?";
        public string vertigo = "?";
        public string eyeVisions = "?";
        public string nosebleeds = "?";
        public string suddenAttack = "?";
        public string afterActivityAttack = "?";
        public string chestOrHeartPain = "?????";
        public string chestOrHeartPressure = "??";
        public string heartPainIrradiation = "??????";
        public string heartPace = "???";
        public string sweat = "??";
        public string hardBreath = "??????";
        public string fear = "?";
        public string weakness = "?";
        public string nausea = "?";
        public string vomiting = "?";
        public string lungsEdema = "?";
        public string lungsSputum = "?";
        public string cough = "????";
        public string legsEdema = "?";
        public string constipation = "?";
        public string appetite = "?";
        public string cyanosis = "?";
        public string weightGain = "?";
        public string freqUrination = "??";
        public string wheezing = "?";
        public string neckVeinIncrease = "?";
        public string skinYellowness = "?";
        public string liverIncrease = "?";
        public string endemas = "?";
        public string hypochondriumPain = "???";
        public string temperature = "?";
        public string fainting = "?";
        public string whiteSkin = "?";
        public string drySkin = "?";
        public string wetSkin = "?";
        public string cold = "?";
        public string stomachache = "?";
        public string orientationLoss = "?";
        public string movementViolation = "??";
        public string feelingViolation = "??";
        public string speechViolation = "?";
        public string sightViolation = "??";
        public string coordinationViolation = "?";
        public string mouthDryness = "?";
        public string heat = "?";
        public string epilepsy = "?";
        public string jointPain = "?";
        public string skinColorChange = "?";
        public string fingerCyanosis = "?";
        public string redFingers = "?";
        public string loseFingersFeeling = "?";
        public string fingerUlcers = "?";
        public string legsPain = "??";
        public string legsSeverity = "?";
        public string legsTremorr = "?";
        public string skinItching = "?";
        public string legsDarking = "?";
        public string nailsFragile = "?";
        public string hairLoss = "?";
        public string thirst = "?";
        public string symptomsString = "";

        public void makeSuperstring()
        {
            symptomsString = thirst + hairLoss + nailsFragile + legsDarking + skinItching + legsTremorr + legsSeverity + legsPain + fingerUlcers+ loseFingersFeeling+ redFingers+ fingerCyanosis+ skinColorChange+ jointPain+ epilepsy+heat+ mouthDryness+ coordinationViolation+ sightViolation+ speechViolation+ feelingViolation+ movementViolation+ orientationLoss+ stomachache+ cold+ wetSkin+ drySkin+ whiteSkin+ fainting+ temperature+ hypochondriumPain+ endemas+ liverIncrease+ skinYellowness+ neckVeinIncrease+ wheezing+ freqUrination+ weightGain+ cyanosis+ appetite+ constipation+ legsEdema+ cough+ lungsSputum+ lungsEdema+ vomiting+ nausea+ weakness+ fear+ hardBreath+ sweat+ heartPace+ heartPainIrradiation+ chestOrHeartPressure+ chestOrHeartPain+ afterActivityAttack+ suddenAttack+ nosebleeds+ eyeVisions+ vertigo+ earNoise+lowPressure+highPressure+headache;
        }

        public CurrentSymptoms(List<string> _symptomsList)
        {
            symptomsList = _symptomsList;
        }

        public void RecognizeSymptoms()
        {
            foreach (string symptom in symptomsList)
            {
                if (symptom == "головная боль")
                {
                    headache = "+" + headache.Substring(1);
                }
                if (symptom == "повышение давления")
                {
                    highPressure = "+" + highPressure.Substring(1);
                }
                if (symptom == "понижение давления")
                {
                    lowPressure = "+";
                }
                if (symptom == "шум в ушах")
                {
                    earNoise = "+";
                }
                if (symptom == "головокружение")
                {
                    vertigo = "+";
                }
                if (symptom == "видения перед глазами")
                {
                    eyeVisions = "+";
                }
                if (symptom == "носовые кровотечения")
                {
                    nosebleeds = "+";
                }
                if (symptom == "боль в грудной клетке" || symptom == "боль в области сердца")
                {
                    chestOrHeartPain = "?+???";
                }
                if (symptom == "учащённое сердцебиение")
                {
                    heartPace = "+" + heartPace.Substring(1);
                }
                if (symptom == "разреженное сердцебиение")
                {
                    heartPace = heartPace[0] + "+" + heartPace[2];
                }
                if (symptom == "перебои в работе сердца")
                {
                    heartPace = heartPace[0] + heartPace[1] + "+";
                }

                if (symptom == "потливость")
                {
                    sweat = "+" + sweat[1];
                }

                if (symptom == "одышка")
                {
                    hardBreath = "+" + hardBreath.Substring(1);
                }

                if (symptom == "чувство страха")
                {
                    fear = "+";
                }

                if (symptom == "общая слабость")
                {
                    weakness = "+";
                }

                if (symptom == "тошнота")
                {
                    nausea = "+";
                }

                if (symptom == "рвота")
                {
                    vomiting = "+";
                }

                if (symptom == "отёк легких")
                {
                    lungsEdema = "+";
                }

                if (symptom == "наличие жидкости в легких")
                {
                    lungsSputum = "+";
                }

                if (symptom == "кашель")
                {
                    cough = "+" + cough.Substring(1);
                }

                if (symptom == "сухой кашель")
                {
                    cough = cough[0] + "+" + cough[2] + cough[3];
                }

                if (symptom == "влажный кашель")
                {
                    cough = cough[0] + cough[1] + "+" + cough[3];
                }

                if (symptom == "кровь в мокроте" || symptom == "кровохарканье")
                {
                    cough = cough[0] + cough[1] + cough[2] + "+";
                }

                if (symptom == "отёки нижних конечностей")
                {
                    legsEdema = "+";
                }

                if (symptom == "запор")
                {
                    constipation = "+";
                }

                if (symptom == "потеря аппетита")
                {
                    appetite = "+";
                }

                if ((symptom.Contains("цианоз")|| symptom.Contains("посинен")) && !(symptom == "цианоз пальцев" || symptom == "посинение пальцев"))
                {
                    cyanosis = "+";
                }

                if (symptom == "увеличение веса")
                {
                    weightGain = "+";
                }

                if (symptom == "частое мочеиспускание")
                {
                    freqUrination = "+" + freqUrination.Substring(1);
                }

                if (symptom == "охриплость")
                {
                    wheezing = "+";
                }

                if (symptom == "набухание вен на шее")
                {
                    neckVeinIncrease = "+";
                }

                if (symptom == "желтизна кожи")
                {
                    skinYellowness = "+";
                }

                if (symptom == "увеличение печени")
                {
                    liverIncrease = "+";
                }

                if (symptom.Contains("отёк"))
                {
                    endemas = "+";
                }

                if (symptom == "боль в подреберье")
                {
                    hypochondriumPain = "+" + hypochondriumPain.Substring(1);
                }

                if (symptom == "обморочное состояние")
                {
                    fainting = "+";
                }

                if (symptom == "повышенная температура")
                {
                    temperature = "+";
                }

                if (symptom == "чувство холода")
                {
                    cold = "+";
                }

                if (symptom == "повышенная влажность кожи")
                {
                    wetSkin = "+";
                }

                if (symptom == "сухость кожи")
                {
                    drySkin = "+";
                }

                if (symptom == "бледность кожи")
                {
                    whiteSkin = "+";
                }

                if (symptom == "проблемы с ориентировкой")
                {
                    orientationLoss = "+";
                }

                if (symptom == "боль в животе")
                {
                    stomachache = "+";
                }

                if (symptom.Contains("паралич") || symptom.Contains("скованность"))
                {
                   movementViolation = "+" + movementViolation.Substring(1);
                }

                if (symptom == "шаткость, неустойчивость")
                {
                    coordinationViolation= "+";
                }

                if (symptom == "ухудшение/потеря зрения")
                {
                    sightViolation = "+" + sightViolation.Substring(1);
                }

                if (symptom == "нарушение речи" || symptom == "затруднённая речь")
                {
                    speechViolation = "+";
                }

                if (symptom.Contains("онемен") || symptom.Contains("покалыв")  || symptom.Contains("жжен"))
                {
                    feelingViolation = "+" + feelingViolation.Substring(1);
                }

                if (symptom == "сухость во рту")
                {
                    mouthDryness = "+";
                }

                if (symptom == "чувство жара")
                {
                    heat = "+";
                }

                if (symptom == "эпилептический припадок")
                {
                    epilepsy = "+";
                }

                if (symptom == "боль в суставах")
                {
                    jointPain = "+";
                }

                if (symptom == "изменение внешнего вида кожи")
                {
                    skinColorChange = "+";
                }

                if (symptom == "цианоз пальцев" || symptom == "посинение пальцев")
                {
                    fingerCyanosis = "+";
                }

                if (symptom == "раны (язвы) на пальцах")
                {
                    fingerUlcers = "+";
                }

                if (symptom.Contains("пальц") && (symptom.Contains("боль") || symptom.Contains("покалыв")|| symptom.Contains("онемен")|| symptom.Contains("жжен")))
                {
                    loseFingersFeeling = "+";
                }

                if (symptom == "кожный зуд")
                {
                    skinItching = "+";
                }

                if (symptom == "хрупкость ногтей")
                {
                    nailsFragile = "+";
                }

                if (symptom == "боль в нижних конечностях")
                {
                    legsPain = "+" + legsPain.Substring(1);
                }

                if (symptom == "потемнение нижних конечностей" || symptom == "почернение нижних конечностей")
                {
                    legsDarking = "+";
                }

                if (symptom.Contains("выпадение волос"))
                {
                    hairLoss = "+";
                }

                if (symptom == "тяжесть в ногах")
                {
                    legsSeverity = "+";
                }

                if (symptom == "судороги в ногах")
                {
                    legsTremorr = "+";
                }

                if (symptom == "повышенная жажда")
                {
                    thirst = "+";
                }

                if (symptom == "покраснение пальцев")
                {
                    redFingers = "+";
                }
            }
        }
    }
}
