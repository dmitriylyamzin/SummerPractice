// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.14.0

using AdaptiveCards;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SC.Bots
{
    public class EchoBot : ActivityHandler
    {
        private static int message_number = 0;
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {


            switch (message_number)
            {
                case 0:
                    await MakeAgeQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 1:
                    await MakeSexQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 2:
                    await MakeWeightQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 3:
                    await MakeHeightQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 4:
                    await MakeCVDQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 5:

                    if (turnContext.Activity.Value.ToString() == "��")
                    {
                        await MakeCVDList(turnContext, cancellationToken);
                        message_number += 1;
                    }
                    else
                    {
                        await MakeCDQuestion(turnContext, cancellationToken);
                        message_number += 2;
                    }
                    break;
                case 6:
                    await MakeCDQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 7:
                    if (turnContext.Activity.Value.ToString() == "��")
                    {
                        await MakeCDList(turnContext, cancellationToken);
                        message_number += 1;
                    }
                    else
                    {
                        await MakeIDQuestion(turnContext, cancellationToken);
                        message_number += 2;
                    }
                    break;
                case 8:
                    await MakeIDQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 9:
                    if (turnContext.Activity.Value.ToString() == "��")
                    {
                        await MakeIDList(turnContext, cancellationToken);
                        message_number += 1;
                    }
                    else
                    {
                        await MakeRDQuestion(turnContext, cancellationToken);
                        message_number += 2;
                    }
                    break;
                case 10:
                    await MakeRDQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 11:
                    await MakeAlcoholQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 12:
                    await MakeSmokeQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 13:
                    await MakeFoodQualityQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 14:
                    await MakeAllergyQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
                case 15:
                    await MakeInjuryQuestion(turnContext, cancellationToken);
                    message_number += 1;
                    break;
            }

        }

        protected async Task MakeCVDQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��������������� �� � ���",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� - ���������� �����������?",

                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeCDQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� �� � ��� ����������� �����������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��������� ������ ���������� �� ������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeRDQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� �� � ��� ������������ (��������, �������)",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });

            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ��������-����������� �������������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeAlcoholQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������������ �� �� ��������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��, ���������",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��, �������� �����",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��, �� �����",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeSmokeQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� �� � ��� ���� � ������� ��� ������������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���� �������� ���������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���, �� ������ ����",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeIDQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������ �� �� � ��������� 6 ������� �������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��� ������� ������������� �������������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "���������� �������� �����?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeAllergyQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��������� �� ��� ������ �������� ��������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeInjuryQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� �� �� � ������� ��������� ��� �������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = " ������ �����, ����� ��� ������� ������?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "���",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�� ����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeFoodQualityQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "7",
                Min = 0,
                Max = 10,
                Label = "������� �������� ������ ������� �� ����� �� 0 �� 10",
                Value = 0
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeActivityQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "8",
                Min = 0,
                Max = 10,
                Label = "������� ������� ����� ���������� ���������� �� ����� �� 0 �� 10",
                Value = 0
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeCVDList(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�����������, ���������� ��� ��������� � ��� ��������-���������� �����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "4"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeCDList(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�����������, ����������, ��������� � ��� ����������� �����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "5"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeIDList(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�����������, ����������, ������� ����������� ���� ������������ �����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextInput
            {
                Id = "6"
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeAgeQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������� ��� ���?",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "1",
                Min = 0,
                Max = 120,
                Value = 40
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeSexQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "�������� ���� ���",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�������",
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�������",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeWeightQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "2",
                Min = 20,
                Max = 200,
                Label = "����� � ��� ���?",
                Value = 70
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task MakeHeightQuestion(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveNumberInput
            {
                Id = "3",
                Min = 110,
                Max = 230,
                Label = "����� � ��� ����?",
                Value = 170
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "�����",
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected async Task CreateStartingCard(ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            AdaptiveCard card = new AdaptiveCard();
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "������������!",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ������� ������� ���-���� �� ������ ������,",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "��������������� �� ��������� � ��� ��������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Body.Add(new AdaptiveTextBlock
            {
                Text = "� ������� �������� - ���������� �����������",
                Size = AdaptiveTextSize.Medium,
                HorizontalAlignment = AdaptiveHorizontalAlignment.Center
            });
            card.Actions.Add(new AdaptiveSubmitAction
            {
                Title = "��������� ��������"
            });
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            await turnContext.SendActivityAsync(MessageFactory.Attachment(attachment), cancellationToken);
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await CreateStartingCard(turnContext, cancellationToken);
                }
            }
        }
    }
}
