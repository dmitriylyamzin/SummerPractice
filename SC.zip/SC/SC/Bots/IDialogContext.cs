﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.14.0

using Microsoft.Bot.Schema;
using System.Threading.Tasks;

namespace SC.Bots
{
    public interface IDialogContext
    {
        Activity MakeMessage();
    }
}